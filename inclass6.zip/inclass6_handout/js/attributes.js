$(function() {
    $('li#three').removeClass('hot');
    $('li.hot').addClass('favorite');
    $('ul').atrr('id','group');

});